//
//  MainViewModel.swift
//  AIChallenge
//
//  Created by Максим Ламанский on 16.03.26.
//

import Foundation
import Combine
import MCP

@MainActor
class MainViewModel: ObservableObject {
    
    @Published var answer: String = ""
    @Published var ollamaChunk: OllamaChunk?
    @Published var ragStatus: String = ""
    
    var currentPrompt: PromptTemplate? = nil
    var settings: [String : Any] = [:]
    var provider: LLMProvider = .ollama
    var userProfile: UserProfile = UserProfile.defaultProfile
    var isTaskPlanningEnabled: Bool = false
    var ragAnswerMode: RAGAnswerMode = .disabled
    var ragSourceType: RAGSourceType = .mcpServer
    var ragChunkingStrategy: RAGChunkingStrategy = .fixedTokens
    var ragRetrievalMode: RAGRetrievalMode = .basic
    var ragEvaluationMode: RAGEvaluationMode = .disabled
    var ragRetrievalSettings: RAGRetrievalSettings = .default
    var isRAGVerboseIndexingEnabled: Bool = false
    
    let ollama: OllamaAgent
    
    let openRouter = OpenRouterAgent()
    
    let settingsObserver: SettingsObserver = SettingsObserver()
    let profileObserver: UserProfileObserver = UserProfileObserver()
    private let indexingService: DocumentIndexingServiceProtocol = DocumentIndexingService()
    private let ragMCPClient: RAGMCPClient
    private var ragStatusLines: [String] = []
    private var pendingAnswerTokens: String = ""
    private var answerFlushWorkItem: DispatchWorkItem?
    private let answerFlushInterval: TimeInterval = 0.08
    
    var uns: Set<AnyCancellable> = []
    
    
    init() {
        let ragMCPClient = RAGMCPClient()
        self.ragMCPClient = ragMCPClient
        self.ollama = OllamaAgent(ragMCPClient: ragMCPClient)
        setupListeners()
    }

    deinit {
        answerFlushWorkItem?.cancel()
        uns.forEach { $0.cancel() }
    }
    
    // TODO: Show statistics view
    var isStatisticsBtnDisabled: Bool {
        ollamaChunk == nil
    }

    func setupListeners() {
        settingsObserver.settings.sink { [weak self] settings in
            guard let self else { return }
            if !settings.isEmpty {
                self.settings = settings
            }
        }.store(in: &uns)
        
        settingsObserver.provider.sink { [weak self] provider in
            guard let self else { return }
            self.provider = provider
        }.store(in: &uns)
        
        settingsObserver.contextStrategy.sink { [weak self] contextStrategy in
            guard let self else { return }
            switch contextStrategy {
            case .slidingWindow:
                ollama.set(strategy: SlidingWindowStrategy(maxMessages: Constants.maxMessages))
            case .facts:
                ollama.set(strategy: FactsStrategy(maxMessages: Constants.maxMessages, agentId: provider.agentId))
            case .branching:
                ollama.set(strategy: BranchingStrategy())
            }
        }.store(in: &uns)
        
        settingsObserver.isTaskPlanningEnabled.sink { [weak self] isTaskPlanningEnabled in
            guard let self else { return }
            self.isTaskPlanningEnabled = isTaskPlanningEnabled
            ollama.setTaskPlanningEnabled(isTaskPlanningEnabled)
        }.store(in: &uns)
        
        settingsObserver.ragChunkingStrategy.sink { [weak self] ragChunkingStrategy in
            guard let self else { return }
            self.ragChunkingStrategy = ragChunkingStrategy
            ollama.setRAGChunkingStrategy(ragChunkingStrategy)
        }.store(in: &uns)

        settingsObserver.ragSourceType.sink { [weak self] ragSourceType in
            guard let self else { return }
            self.ragSourceType = ragSourceType
            ollama.setRAGSourceType(ragSourceType)
        }.store(in: &uns)
        
        settingsObserver.ragAnswerMode.sink { [weak self] ragAnswerMode in
            guard let self else { return }
            self.ragAnswerMode = ragAnswerMode
            ollama.setRAGAnswerMode(ragAnswerMode)
        }.store(in: &uns)
        
        settingsObserver.ragRetrievalMode.sink { [weak self] ragRetrievalMode in
            guard let self else { return }
            self.ragRetrievalMode = ragRetrievalMode
            ollama.setRAGRetrievalMode(ragRetrievalMode)
        }.store(in: &uns)
        
        settingsObserver.ragEvaluationMode.sink { [weak self] ragEvaluationMode in
            guard let self else { return }
            self.ragEvaluationMode = ragEvaluationMode
            ollama.setRAGEvaluationMode(ragEvaluationMode)
        }.store(in: &uns)

        settingsObserver.isRAGVerboseIndexingEnabled.sink { [weak self] isEnabled in
            self?.isRAGVerboseIndexingEnabled = isEnabled
        }.store(in: &uns)
        
        settingsObserver.ragRetrievalSettings.sink { [weak self] ragRetrievalSettings in
            guard let self else { return }
            self.ragRetrievalSettings = ragRetrievalSettings
            ollama.setRAGRetrievalSettings(ragRetrievalSettings)
        }.store(in: &uns)
        
        profileObserver.selectedProfile
            .sink { [weak self] profile in
                guard let self, let profile else { return }
                print("Selected profile:", profile.userId)
                ollama.setUser(profile)
            }
            .store(in: &uns)
    }
    
    func start(prompt: PromptTemplate? = .recursionExpl) {
        switch provider {
        case .ollama:
            startOllama(prompt: prompt)
        case .openRouter:
            startOpenRouter(prompt: prompt)
        case .privateLocalLLM:
            startOllama(prompt: prompt)
        }
    }
    
    func deleteAll() {
        resetAnswerBuffer()
        answer = ""
        ragStatus = ""
        
        switch provider {
        case .ollama:
            ollama.deleteAllAgentData()
        case .openRouter:
            openRouter.deleteAllMessages()
        case .privateLocalLLM:
            ollama.deleteAllAgentData()
        }
    }
    
    func startOllama(prompt: PromptTemplate? = .recursionExpl) {
        guard let prompt else { return }
        resetAnswerBuffer()
        clearRAGStatusDisplay()
        
        if currentPrompt != .promptWithStopWord {
            currentPrompt = prompt
        }
        
        let storeOrErase: () -> Void = {
            guard self.currentPrompt != .promptWithStopWord else { return }
            self.answer = ""
        }
        
        switch prompt {
        case .recursionExpl: storeOrErase()
        case .recursionExplAsJSON: storeOrErase()
        case .promptWithStopWord: storeOrErase()
        case .stopWord: currentPrompt = nil
        case .someText: storeOrErase()
        }
        
        ollama.onToken = { token in
            Task { @MainActor [weak self] in
                self?.enqueueAnswerToken(token)
            }
        }
        
        ollama.onComplete = { [weak self] ollamaChunk in
            Task { @MainActor [weak self] in
                guard let self else { return }
                flushPendingAnswerTokens()
                appendCompactLocalStatsIfNeeded(from: ollamaChunk)
                self.ollamaChunk = ollamaChunk
            }
        }

        answer += "\n\nYou: \(prompt.text)\n\n"
        
        ollama.send(
            prompt,
            options: settings
        )
   }
    
    func startOpenRouter(prompt: PromptTemplate? = .recursionExpl) {
        guard let prompt else { return }
        resetAnswerBuffer()
        clearRAGStatusDisplay()
        
        if currentPrompt != .promptWithStopWord {
            currentPrompt = prompt
        }
        
        let storeOrErase: () -> Void = {
            guard self.currentPrompt != .promptWithStopWord else { return }
            self.answer = ""
        }
        
        switch prompt {
        case .recursionExpl: storeOrErase()
        case .recursionExplAsJSON: storeOrErase()
        case .promptWithStopWord: storeOrErase()
        case .stopWord: currentPrompt = nil
        case .someText: storeOrErase()
        }
        
        openRouter.onToken = { [weak self] token in
            Task { @MainActor [weak self] in
                self?.enqueueAnswerToken(token)
            }
        }
        
        openRouter.onComplete = { [weak self] token in
            Task { @MainActor [weak self] in
                self?.flushPendingAnswerTokens()
            }
        }

        answer += "\n\nYou: \(prompt.text)\n\n"
        
        openRouter.send(
            prompt,
            options: settings
        )
   }
    
    private func enqueueAnswerToken(_ token: String) {
        pendingAnswerTokens += token
        
        guard answerFlushWorkItem == nil else {
            return
        }
        
        let workItem = DispatchWorkItem { [weak self] in
            Task { @MainActor [weak self] in
                self?.flushPendingAnswerTokens()
            }
        }
        
        answerFlushWorkItem = workItem
        DispatchQueue.main.asyncAfter(
            deadline: .now() + answerFlushInterval,
            execute: workItem
        )
    }
    
    private func flushPendingAnswerTokens() {
        answerFlushWorkItem?.cancel()
        answerFlushWorkItem = nil
        
        guard !pendingAnswerTokens.isEmpty else {
            return
        }
        
        answer += pendingAnswerTokens
        pendingAnswerTokens = ""
    }
    
    private func resetAnswerBuffer() {
        answerFlushWorkItem?.cancel()
        answerFlushWorkItem = nil
        pendingAnswerTokens = ""
    }

    private func appendCompactLocalStatsIfNeeded(from chunk: OllamaChunk) {
        guard localRuntimeReportingSettings().appendCompactStatsToAnswer,
              let localStats = chunk.localStats else {
            return
        }

        answer += "\n\n" + localStats.compactSummary
    }

    private func localRuntimeReportingSettings() -> LocalRuntimeReportingSettings {
        let rawSettings = settings["local_runtime"] as? [String: Any] ?? [:]
        return LocalRuntimeReportingSettings(dictionary: rawSettings)
    }
    
    func setTaskRunState(isPause: Bool) {
        if isPause {
            ollama.pauseTask()
        } else {
            ollama.resumeTask()
        }
    }
    
    func indexDocuments(urls: [URL]) {
        ragStatusLines = []
        appendRAGStatus(
            ragSourceType == .mcpServer
            ? "Indexing documents through RAG MCP server..."
            : "Indexing documents with built-in RAG..."
        )
        
        Task {
            let accessibleURLs = urls.filter { $0.startAccessingSecurityScopedResource() }
            let indexingURLs = accessibleURLs.isEmpty ? urls : accessibleURLs
            
            defer {
                accessibleURLs.forEach { $0.stopAccessingSecurityScopedResource() }
            }
            
            do {
                let summary: RAGIndexingSummary

                switch ragSourceType {
                case .mcpServer:
                    guard let zipURL = indexingURLs.first(where: { $0.pathExtension.lowercased() == "zip" }) else {
                        appendRAGStatus("RAG MCP indexing expects a .zip archive. Please select a zip file.")
                        return
                    }

                    appendRAGStatus("Uploading zip path to RAG MCP: \(zipURL.lastPathComponent)")
                    if isRAGVerboseIndexingEnabled {
                        appendRAGStatus("Tool: rag_index_zip")
                        appendRAGStatus("Archive: \(zipURL.path)")
                    }
                    summary = try await ragMCPClient.indexZip(
                        url: zipURL,
                        strategy: ragChunkingStrategy,
                        replaceExisting: true
                    )
                case .builtIn:
                    let progress: (RAGIndexingProgress) async -> Void = { [weak self] event in
                        await MainActor.run {
                            self?.appendRAGStatus(event)
                        }
                    }

                    summary = try await indexingService.index(
                        urls: indexingURLs,
                        strategy: ragChunkingStrategy,
                        progress: isRAGVerboseIndexingEnabled ? progress : nil
                    )
                }
                ollama.invalidateRAGRetrievalCache()
                
                appendRAGStatus(makeRAGIndexingSummaryText(summary))
            } catch {
                print(error)
                print(error.localizedDescription)
                ragStatus = "RAG indexing failed: \(error.localizedDescription)"
            }
        }
    }
    
    private func appendRAGStatus(_ event: RAGIndexingProgress) {
        switch event {
        case .started(let strategy):
            appendRAGStatus("[\(strategy.rawValue)] started")
        case .documentsLoaded(let strategy, let files):
            appendRAGStatus("[\(strategy.rawValue)] loaded files: \(files.count)")
            
            for file in files.prefix(10) {
                appendRAGStatus("- \(file)")
            }
            
            if files.count > 10 {
                appendRAGStatus("- ... +\(files.count - 10) more")
            }
        case .chunksCreated(let strategy, let chunks):
            appendRAGStatus("[\(strategy.rawValue)] chunks created: \(chunks.count)")
            
            for chunk in chunks.prefix(12) {
                appendRAGStatus(
                    "- \(chunk.title) #\(chunk.chunkId), tokens: \(chunk.tokenCount), section: \(chunk.section)"
                )
            }
            
            if chunks.count > 12 {
                appendRAGStatus("- ... +\(chunks.count - 12) more chunks")
            }
        case .embeddingCreated(let strategy, let chunk, let embeddingPreview):
            let preview = embeddingPreview
                .map { String(format: "%.4f", Double($0)) }
                .joined(separator: ", ")
            
            appendRAGStatus(
                "[\(strategy.rawValue)] embedded \(chunk.title) #\(chunk.chunkId), tokens: \(chunk.tokenCount), vector: [\(preview)]"
            )
        case .saved(let strategy, let chunkCount):
            appendRAGStatus("[\(strategy.rawValue)] saved to SQLite: \(chunkCount) chunks")
        }
    }
    
    private func appendRAGStatus(_ line: String) {
        ragStatusLines.append(line)
        ragStatusLines = Array(ragStatusLines.suffix(50))
        ragStatus = ragStatusLines.joined(separator: "\n")
    }

    private func makeRAGIndexingSummaryText(_ summary: RAGIndexingSummary) -> String {
        let databaseText: String
        if isRAGVerboseIndexingEnabled, let databasePath = summary.databasePath {
            databaseText = "\ndatabase: \(databasePath)"
        } else {
            databaseText = ""
        }

        return """
        RAG index ready.

        Source: \(ragSourceType.title)
        Strategy: \(summary.strategy.title)
        documents: \(summary.documentCount)
        chunks: \(summary.chunkCount), avg tokens: \(Int(summary.averageTokens))
        min tokens: \(summary.minTokens), max tokens: \(summary.maxTokens)
        model: \(summary.embeddingModel)\(databaseText)
        duration: \(String(format: "%.2f", summary.duration))s
        """
    }
    
    private func clearRAGStatusDisplay() {
        ragStatusLines = []
        ragStatus = ""
    }
    
    @MainActor
    func createSummaryJobAndOpen(
        owner: String,
        repo: String,
        openScreen: @escaping (String) -> Void
    ) {
        let mcpToolExecutor: MCPToolExecutor = MCPToolExecutor(endpoint: URL(string: Constants.mcpServerLocalHGitHub_URI)!)

        Task {
            do {
                let result = try await mcpToolExecutor.callTool(
                    name: "schedule_summary",
                    arguments: [
                        "owner": .string(owner),
                        "repo": .string(repo),
                        "interval_seconds": .double(6)
                    ]
                )

                guard let jobId = JobIDParser.extractJobID(from: result.content) else {
                    print("Failed to parse job ID from: \(result.content)")
                    return
                }

                openScreen(jobId)
            } catch {
                print("Failed to schedule summary: \(error.localizedDescription)")
            }
        }
    }
}
