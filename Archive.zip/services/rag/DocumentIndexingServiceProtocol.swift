//
//  DocumentIndexingServiceProtocol.swift
//  AIChallenge
//
//  Created by Codex on 13.04.26.
//

import Foundation

protocol DocumentIndexingServiceProtocol {
    func index(urls: [URL], strategy: RAGChunkingStrategy) async throws -> RAGIndexingSummary
}
