//
//  OllamaEmbeddingService.swift
//  AIChallenge
//
//  Created by Codex on 13.04.26.
//

import Foundation

struct OllamaEmbeddingService: EmbeddingServiceProtocol {
    let endpoint = URL(string: "http://127.0.0.1:11434/api/embed")!
    let model = "nomic-embed-text"
    
    private struct RequestBody: Encodable {
        let model: String
        let input: [String]
    }
    
    private struct ResponseBody: Decodable {
        let embeddings: [[Float]]
    }
    
    func embed(_ texts: [String]) async throws -> [[Float]] {
        guard !texts.isEmpty else { return [] }
        
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(
            RequestBody(model: model, input: texts)
        )
        
        let (data, _) = try await URLSession.shared.data(for: request)
        let response = try JSONDecoder().decode(ResponseBody.self, from: data)
        
        return response.embeddings.map(Self.normalize)
    }
    
    static func normalize(_ vector: [Float]) -> [Float] {
        guard let maxElement = vector.max(), maxElement != 0 else {
            return vector
        }
        
        return vector.map { $0 / maxElement }
    }
}
